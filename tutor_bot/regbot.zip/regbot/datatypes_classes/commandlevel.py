"""
    Класс направления Команда.
    Идет перенаправление в зависимости от полученной комманды бота.
"""

from .datatypesclass import Observer, Subject


class CommandCancel(Observer):
    def update(self, subject: Subject, bot, local, admin) -> None:
        if subject._state == 'cancel':
            if admin:
                local.admin_edit(state='')
            else:
                local.temp_admin_edit(state='')
            answer = {
                'chat_id': local.chat_id,
                'text': 'Текущая операция отменена!',
            }
            bot.send_answer(answer)
