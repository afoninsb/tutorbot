from .inline import (admin_kbrd, items_kbrd, plans_kbrd,
                     push_kr_kbrd, reply_kbrd)
from .main import main_kbrd
