from .botdata import BotData
from .localdata import LocalData
